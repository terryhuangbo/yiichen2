<?php
return [
	//memcached
	'memcache_host' => '127.0.0.1',
    'memcache_port' => 11211,
	//文章默认图片
    'defautl_post_img' => get_bloginfo('template_url') . '/images/default-page-pic.png',    
    //关于我们
    'about_url' => 'http://www.yca.com/?page_id=2',
    //微信页面
    'wechat_url' => 'http://www.yca.com/?page_id=12904',

];

?>