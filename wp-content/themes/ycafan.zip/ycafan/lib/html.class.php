<?php
/**
 * 公共方法类-用于输出固定格式的HTML
 **/
class HTML {

    public function __construct() {

    }


}

?>