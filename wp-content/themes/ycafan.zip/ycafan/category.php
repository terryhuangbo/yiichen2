<?php
/**
 * 文章分类页
 */
include(TEMPLATEPATH . '/category-common.php');
//get_template_part('category', 'common');
?>


