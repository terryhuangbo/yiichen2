<!-- 获取头部 --><!-- 获取头部 --><!-- 获取头部 --><!-- 获取头部 -->
<?php get_header(); ?>

<div id="content-outer" class="content-outer clearfix fix-header-height">
<div id="content" class="content clearfix">
  <div class="header-notice-wrap header-notice-wrap-for-home">
    <div class="fullwidth">
      <div class="header-notice hide J_Notice">
        <a class="notice J_NoticeLink" href="#">
          <i class="iycar2015 iycar2015-live">
          </i>
          <span class="J_NoticeTitle">
          </span>
        </a>
        <a class="J_Close close reverse-icon" title="关闭">
          <i class="icon-remove">
          </i>
        </a>
      </div>
    </div>
  </div>
  <div id="recommend-post" class="clearfix">
    <div id="recommend-post-slider" class="recommend-holder clearfix">
      <div class="recommend-post-content clearfix">
        <div class="slider">
          <ul>
            <li class="iycar-recommend-item">
              <div class="post-mask post-mask-top">
              </div>
              <div class="post-mask post-mask-bottom">
              </div>
              <div itemprop="url" href="http://www.iycar.com/628741" class="iycar-recommend-items">
                <div class="item-content">
                  <div class="bg-img" data-cmpt-parallax-bg id="recommend" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/DIY-3.jpg')">
                  </div>
                  <div class="fullwidth">
                    <div class="main recommend-post-wrapper row">
                      <div class="post-item-container excerpt" itemscope itemtype="http://schema.org/Article">
                        <div class="fullwidth">
                          <div class="main row">
                            <div class="post-item-container title">
                              <div class="post-item-addon">
                              </div>
                              <div class="post-item-content" itemscope itemtype="http://schema.org/Article">
                                <meta itemscope="thumbnailUrl" content="http://images.iycar.cn/wp-content/uploads/2016/03/DIY-3.jpg"
                                />
                                <div class="tag-label">
                                  <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/product">
                                    产品
                                  </a>
                                  <span class="seperator">
                                    |
                                  </span>
                                  <span class="author">
                                    <a href="http://www.iycar.com/author/iycarvideo" title="Posts by 爱范儿视频"
                                    rel="author">
                                      爱范儿视频
                                    </a>
                                  </span>
                                  <meta itemprop="author" content="爱范儿视频" />
                                </div>
                                <h2 itemprop="headline">
                                  <a rel="canonical" itemprop="url" href="http://www.iycar.com/628741" class="js-multiline">
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        【视频直播】组一部一万元的台式机是什么感
                                      </span>
                                    </div>
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        觉？
                                      </span>
                                    </div>
                                  </a>
                                </h2>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="post-item-content post-item-excerpt">
                          <div itemprop="description" class="js-excerpt" data-clamp='3'>
                            <p>
                              看着这配置，再看看自己那台，我哭了。
                            </p>
                          </div>
                        </div>
                        <div class="clearfix">
                        </div>
                      </div>
                      <!-- post-item-container -->
                    </div>
                  </div>
                  <!-- recommend-post-wrapper -->
                </div>
                <!-- item-content -->
              </div>
            </li>
            <li class="iycar-recommend-item">
              <div class="post-mask post-mask-top">
              </div>
              <div class="post-mask post-mask-bottom">
              </div>
              <div itemprop="url" href="http://www.iycar.com/628151" class="iycar-recommend-items">
                <div class="item-content">
                  <div class="bg-img" data-cmpt-parallax-bg id="recommend" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/aed82cd7web-china-game-go-1-cc-e1457075761960.jpg')">
                  </div>
                  <div class="fullwidth">
                    <div class="main recommend-post-wrapper row">
                      <div class="post-item-container excerpt" itemscope itemtype="http://schema.org/Article">
                        <div class="fullwidth">
                          <div class="main row">
                            <div class="post-item-container title">
                              <div class="post-item-addon">
                              </div>
                              <div class="post-item-content" itemscope itemtype="http://schema.org/Article">
                                <meta itemscope="thumbnailUrl" content="http://images.iycar.cn/wp-content/uploads/2016/03/aed82cd7web-china-game-go-1-cc-e1457075761960.jpg"
                                />
                                <div class="tag-label">
                                  <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/innovation">
                                    新创
                                  </a>
                                  <span class="seperator">
                                    |
                                  </span>
                                  <span class="author">
                                    <a href="http://www.iycar.com/author/odyssey" title="Posts by 欧狄" rel="author">
                                      欧狄
                                    </a>
                                  </span>
                                  <meta itemprop="author" content="欧狄" />
                                </div>
                                <h2 itemprop="headline">
                                  <a rel="canonical" itemprop="url" href="http://www.iycar.com/628151" class="js-multiline">
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        5 天后大战人工智能！世界顶尖棋手能否“捍
                                      </span>
                                    </div>
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        卫”人类智商？
                                      </span>
                                    </div>
                                  </a>
                                </h2>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="post-item-content post-item-excerpt">
                          <div itemprop="description" class="js-excerpt" data-clamp='3'>
                            <p>
                              “对 AlphaGO 是我不能输的比赛，甚至一盘棋都不能输。”李世石显得志在必得。
                            </p>
                          </div>
                        </div>
                        <div class="clearfix">
                        </div>
                      </div>
                      <!-- post-item-container -->
                    </div>
                  </div>
                  <!-- recommend-post-wrapper -->
                </div>
                <!-- item-content -->
              </div>
            </li>
            <li class="iycar-recommend-item">
              <div class="post-mask post-mask-top">
              </div>
              <div class="post-mask post-mask-bottom">
              </div>
              <div itemprop="url" href="http://www.iycar.com/628422" class="iycar-recommend-items">
                <div class="item-content">
                  <div class="bg-img" data-cmpt-parallax-bg id="recommend" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/wechat_pay.jpg')">
                  </div>
                  <div class="fullwidth">
                    <div class="main recommend-post-wrapper row">
                      <div class="post-item-container excerpt" itemscope itemtype="http://schema.org/Article">
                        <div class="fullwidth">
                          <div class="main row">
                            <div class="post-item-container title">
                              <div class="post-item-addon">
                              </div>
                              <div class="post-item-content" itemscope itemtype="http://schema.org/Article">
                                <meta itemscope="thumbnailUrl" content="http://images.iycar.cn/wp-content/uploads/2016/03/wechat_pay.jpg"
                                />
                                <div class="tag-label">
                                  <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/business">
                                    商业
                                  </a>
                                  <span class="seperator">
                                    |
                                  </span>
                                  <span class="author">
                                    <a href="http://www.iycar.com/author/michael" title="Posts by 麦玮琪" rel="author">
                                      麦玮琪
                                    </a>
                                  </span>
                                  <meta itemprop="author" content="麦玮琪" />
                                </div>
                                <h2 itemprop="headline">
                                  <a rel="canonical" itemprop="url" href="http://www.iycar.com/628422" class="js-multiline">
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        同是第三方支付，为啥支付宝能顶住手续费压
                                      </span>
                                    </div>
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        力，微信却不能？
                                      </span>
                                    </div>
                                  </a>
                                </h2>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="post-item-content post-item-excerpt">
                          <div itemprop="description" class="js-excerpt" data-clamp='3'>
                            <p>
                              在看不见的地方，支付宝和微信支付的差异非常之大。这也凸显了支付宝在第三方支付上的领先地位，即便它缺少所谓的社交基因；而微信支付需要追赶的，也不仅仅是市场份额。
                            </p>
                          </div>
                        </div>
                        <div class="clearfix">
                        </div>
                      </div>
                      <!-- post-item-container -->
                    </div>
                  </div>
                  <!-- recommend-post-wrapper -->
                </div>
                <!-- item-content -->
              </div>
            </li>
            <li class="iycar-recommend-item">
              <div class="post-mask post-mask-top">
              </div>
              <div class="post-mask post-mask-bottom">
              </div>
              <div itemprop="url" href="http://www.iycar.com/627543" class="iycar-recommend-items">
                <div class="item-content">
                  <div class="bg-img" data-cmpt-parallax-bg id="recommend" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/Robot.jpg')">
                  </div>
                  <div class="fullwidth">
                    <div class="main recommend-post-wrapper row">
                      <div class="post-item-container excerpt" itemscope itemtype="http://schema.org/Article">
                        <div class="fullwidth">
                          <div class="main row">
                            <div class="post-item-container title">
                              <div class="post-item-addon">
                              </div>
                              <div class="post-item-content" itemscope itemtype="http://schema.org/Article">
                                <meta itemscope="thumbnailUrl" content="http://images.iycar.cn/wp-content/uploads/2016/03/Robot.jpg"
                                />
                                <div class="tag-label">
                                  <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/product">
                                    产品
                                  </a>
                                  <span class="seperator">
                                    |
                                  </span>
                                  <span class="author">
                                    <a href="http://www.iycar.com/author/huangmeijing" title="Posts by 黄 美菁"
                                    rel="author">
                                      黄 美菁
                                    </a>
                                  </span>
                                  <meta itemprop="author" content="黄 美菁" />
                                </div>
                                <h2 itemprop="headline">
                                  <a rel="canonical" itemprop="url" href="http://www.iycar.com/627543" class="js-multiline">
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        当真狗狗遇上机器狗，如何面对这些“成精”的
                                      </span>
                                    </div>
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        机器人？
                                      </span>
                                    </div>
                                  </a>
                                </h2>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="post-item-content post-item-excerpt">
                          <div itemprop="description" class="js-excerpt" data-clamp='3'>
                            <p>
                              当 Android 创始人 Andy Rubin 的爱犬遇到机器狗，两者会擦出怎样的火花？
                            </p>
                          </div>
                        </div>
                        <div class="clearfix">
                        </div>
                      </div>
                      <!-- post-item-container -->
                    </div>
                  </div>
                  <!-- recommend-post-wrapper -->
                </div>
                <!-- item-content -->
              </div>
            </li>
            <li class="iycar-recommend-item">
              <div class="post-mask post-mask-top">
              </div>
              <div class="post-mask post-mask-bottom">
              </div>
              <div itemprop="url" href="http://www.iycar.com/627298" class="iycar-recommend-items">
                <div class="item-content">
                  <div class="bg-img" data-cmpt-parallax-bg id="recommend" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/15657723_xxl.jpg')">
                  </div>
                  <div class="fullwidth">
                    <div class="main recommend-post-wrapper row">
                      <div class="post-item-container excerpt" itemscope itemtype="http://schema.org/Article">
                        <div class="fullwidth">
                          <div class="main row">
                            <div class="post-item-container title">
                              <div class="post-item-addon">
                              </div>
                              <div class="post-item-content" itemscope itemtype="http://schema.org/Article">
                                <meta itemscope="thumbnailUrl" content="http://images.iycar.cn/wp-content/uploads/2016/03/15657723_xxl.jpg"
                                />
                                <div class="tag-label">
                                  <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/opinion">
                                    观点
                                  </a>
                                  <span class="seperator">
                                    |
                                  </span>
                                  <span class="author">
                                    <a href="http://www.iycar.com/author/odin" title="Posts by 莊 偉宏 Odin"
                                    rel="author">
                                      莊 偉宏 Odin
                                    </a>
                                  </span>
                                  <meta itemprop="author" content="莊 偉宏 Odin" />
                                </div>
                                <h2 itemprop="headline">
                                  <a rel="canonical" itemprop="url" href="http://www.iycar.com/627298" class="js-multiline">
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        究竟是什么黑科技，让大疆无人机不会撞墙？
                                      </span>
                                    </div>
                                  </a>
                                </h2>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="post-item-content post-item-excerpt">
                          <div itemprop="description" class="js-excerpt" data-clamp='3'>
                            <p>
                              为什么大疆的 Phantom 4 和 Yuneec 的 Typhoon H，可以像有生命的一样自动回避障碍物？全因它们都有一双眼睛。
                            </p>
                          </div>
                        </div>
                        <div class="clearfix">
                        </div>
                      </div>
                      <!-- post-item-container -->
                    </div>
                  </div>
                  <!-- recommend-post-wrapper -->
                </div>
                <!-- item-content -->
              </div>
            </li>
            <li class="iycar-recommend-item">
              <div class="post-mask post-mask-top">
              </div>
              <div class="post-mask post-mask-bottom">
              </div>
              <div itemprop="url" href="http://www.iycar.com/627195" class="iycar-recommend-items">
                <div class="item-content">
                  <div class="bg-img" data-cmpt-parallax-bg id="recommend" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/p4-titu.jpg')">
                  </div>
                  <div class="fullwidth">
                    <div class="main recommend-post-wrapper row">
                      <div class="post-item-container excerpt" itemscope itemtype="http://schema.org/Article">
                        <div class="fullwidth">
                          <div class="main row">
                            <div class="post-item-container title">
                              <div class="post-item-addon">
                              </div>
                              <div class="post-item-content" itemscope itemtype="http://schema.org/Article">
                                <meta itemscope="thumbnailUrl" content="http://images.iycar.cn/wp-content/uploads/2016/03/p4-titu.jpg"
                                />
                                <div class="tag-label">
                                  <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/product">
                                    产品
                                  </a>
                                  <span class="seperator">
                                    |
                                  </span>
                                  <span class="author">
                                    <a href="http://www.iycar.com/author/michael" title="Posts by 麦玮琪" rel="author">
                                      麦玮琪
                                    </a>
                                  </span>
                                  <meta itemprop="author" content="麦玮琪" />
                                </div>
                                <h2 itemprop="headline">
                                  <a rel="canonical" itemprop="url" href="http://www.iycar.com/627195" class="js-multiline">
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        大疆精灵 4 的这十个黑科技，让新手也能把
                                      </span>
                                    </div>
                                    <div class="title-part-container">
                                      <span class="title-part">
                                        无人机玩出花样
                                      </span>
                                    </div>
                                  </a>
                                </h2>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="post-item-content post-item-excerpt">
                          <div itemprop="description" class="js-excerpt" data-clamp='3'>
                            <p>
                              答案就隐藏在这款 Phantom 4 里。
                            </p>
                          </div>
                        </div>
                        <div class="clearfix">
                        </div>
                      </div>
                      <!-- post-item-container -->
                    </div>
                  </div>
                  <!-- recommend-post-wrapper -->
                </div>
                <!-- item-content -->
              </div>
            </li>
          </ul>
        </div>
        <!-- slider -->
      </div>
      <!-- recommend-post-content -->
    </div>
    <!-- recommend-post-slider -->
    <div class="fullwidth">
      <!-- 广告 -->
      <!-- 广告 -->
      <!-- 文章合集 -->
      <div id="iycar-post-collections" class="clearfix">
        <div class="accordion-border">
          <a rel="canonical" class="accordion-item accordion-close" href="http://www.iycar.com/621230">
            我们用 Apple Pay 买了 6 份麦当劳，遇到了这些问题（附解决方案）
            <div class="img-bg" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/iphonepay.jpg!400');">
            </div>
          </a>
          <a rel="canonical" class="accordion-item accordion-close" href="http://www.iycar.com/621212">
            为什么我需要用／不需用 Apple Pay？
            <div class="img-bg" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/DSCF2041.jpg!400');">
            </div>
          </a>
          <a rel="canonical" class="accordion-item accordion-close" href="http://www.iycar.com/621573">
            继 Apple Pay 后，你的三星手机也能吃上麦当劳
            <div class="img-bg" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/20150209_091101.jpg!400');">
            </div>
          </a>
        </div>
      </div>
      <!-- 文章合集 -->
    </div>
  </div>
  <!-- recommend-post -->
  <div id="index-part-one" data-cmpt-autofixed-container class="fullwidth row top  js-index-part-one">
    <div class="main">
      <div class="index-content-normal posts-list">
        <article itemscope itemtype="http://schema.org/Article" id="post-628698"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628698"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/writing.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628698" title="Permalink to 深度的文章、优雅的讨论、赚钱的作者，这些是 Medium 的妄想还是未来？">
                <span itemprop="headline">
                  深度的文章、优雅的讨论、赚钱的作者，这些是 Medium 的妄想还是未来？
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628698#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  0
                </a>
                <meta itemprop="commentCount" content="0" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              在信息泛滥的时代，长文发表平台 Medium 能够做到内容深度、讨论和谐而且作者还能赚到钱吗？
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/business">
                商业
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/huangmeijing" title="Posts by 黄 美菁"
                rel="author">
                  黄 美菁
                </a>
              </span>
              <meta itemprop="author" content="黄 美菁" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T09:57:36+0000">
                1 小时前
              </span>
            </div>
          </div>
        </article>
        <article itemscope itemtype="http://schema.org/Article" id="post-628679"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628679"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/o-WOMAN-BIKE-RIDING-facebook.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628679" title="Permalink to 都知道欧洲人爱骑单车，听说过欧洲的单车高速公路吗？">
                <span itemprop="headline">
                  都知道欧洲人爱骑单车，听说过欧洲的单车高速公路吗？
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628679#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  3
                </a>
                <meta itemprop="commentCount" content="3" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              为了让人们愉快地飙单车，挪威打算花 60 亿修建单车高速路。
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/business">
                商业
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/tiger" title="Posts by 吴 垠" rel="author">
                  吴 垠
                </a>
              </span>
              <meta itemprop="author" content="吴 垠" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T09:28:01+0000">
                2 小时前
              </span>
            </div>
          </div>
        </article>
        <div class="dasheng-wrapper">
          <div class="fullwidth row">
            <span class="dasheng-icon">
              <i class="iycar2015 iycar2015-dasheng">
              </i>
            </span>
            <div class="main">
              <div class="post-item-container">
                <div class="comment-count">
                  <div class="row-dasheng-title">
                    <span class="entry-dasheng-title">
                      <a class="tag" href="http://www.iycar.com/dasheng">
                        大声
                      </a>
                      | 7 小时前
                    </span>
                  </div>
                </div>
                <div class="post-item-content ">
                  <a class="dasheng-index entry-dasheng clearfix" href="http://www.iycar.com/dasheng/628269">
                    <div class="entry-dasheng-inner clearfix">
                      <div class="dasheng_content clearfix">
                        <span>
                          做深度学习的人工智能博士生，现在一毕业就能拿到 200 到 300 万美金的年收入的 offer，这是有史以来没有发生过的。
                        </span>
                        <div class="dasheng_original text-right">
                          <span>
                            ― 李开复
                          </span>
                        </div>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <article itemscope itemtype="http://schema.org/Article" id="post-628441"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628441"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/sanxing.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628441" title="Permalink to 戴上虚拟现实头盔坐过山车，会更恐怖吗？">
                <span itemprop="headline">
                  戴上虚拟现实头盔坐过山车，会更恐怖吗？
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628441#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  2
                </a>
                <meta itemprop="commentCount" content="2" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              坐带有 VR 的过山车是一种什么体验？
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/business">
                商业
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/wanglinlin" title="Posts by 王琳琳"
                rel="author">
                  王琳琳
                </a>
              </span>
              <meta itemprop="author" content="王琳琳" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T06:52:16+0000">
                4 小时前
              </span>
            </div>
          </div>
        </article>
        <article itemscope itemtype="http://schema.org/Article" id="post-628486"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628486"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/DSCF6003-MARKED1.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628486" title="Permalink to 我花 400 买了个智能手环，天天戴，打死不充电">
                <span itemprop="headline">
                  我花 400 买了个智能手环，天天戴，打死不充电
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628486#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  10
                </a>
                <meta itemprop="commentCount" content="10" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              从它表面反射入眼的景物会产生鱼眼一般的畸变，让不停重复的世界有了一丝新奇的生机。
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/product">
                产品
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/tiger" title="Posts by 吴 垠" rel="author">
                  吴 垠
                </a>
              </span>
              <meta itemprop="author" content="吴 垠" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T06:46:59+0000">
                4 小时前
              </span>
            </div>
          </div>
        </article>
        <article itemscope itemtype="http://schema.org/Article" id="post-628473"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628473"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/one.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628473" title="Permalink to 以后你可以在《纸牌屋》中看到这部国产手机了">
                <span itemprop="headline">
                  以后你可以在《纸牌屋》中看到这部国产手机了
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628473#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  12
                </a>
                <meta itemprop="commentCount" content="12" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              今天一加手机刚刚宣布对美剧《纸牌屋》的植入。一加手机将在即将迎来的《纸牌屋》第四季中出现，并希望以此来切入对应地区的消费人群，而植入费用大概为
              200 万左右。
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/business">
                商业
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/jackie" title="Posts by 王 飞" rel="author">
                  王 飞
                </a>
              </span>
              <meta itemprop="author" content="王 飞" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T06:45:40+0000">
                4 小时前
              </span>
            </div>
          </div>
        </article>
      </div>
    </div>
    <div class="sbl row">
      <div data-cmpt-autofixed data-autofixed-follow-to=".js-index-part-one">
        <div class="iycar-sudu-border">
        </div>
        <div id="iycar_side_jiong_widget-81" class="widget-container widget_iycar_jiong_new clearfix">
          <div class="iycar-text-content">
            <a id="video" rel="external" href="http://go.iycar.cn/1S">
              <img src="http://images.iycar.cn/wp-content/uploads/2016/02/cebianlan.jpg"
              />
            </a>
          </div>
        </div>
        <div id="iycar_widget_buzz-2" class="widget-container widget_iycar_widget_buzz clearfix">
          <div class="widget-buzz-container">
            <div class="title-container">
              <i class="iconfont iconfont-buzz">
              </i>
              <h1 class="widget-buzz-title">
                快讯
              </h1>
            </div>
            <div class="nano buzz-list-container js-nano">
              <ul class="buzz-list nano-content js-buzz-list">
                <!-- buzz item -->
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628668" data-source-url="http://tech.qq.com/a/20160304/057055.htm"
                      itemprop="url" class="buzz-item-link">
                        传富士康最快下周签收购夏普协议 注资额不变
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T08:34:24+0000">
                        2 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628668"
                        data-source-url="http://tech.qq.com/a/20160304/057055.htm" class="buzz-item-link">
                          tech.qq.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628667" data-source-url="http://tech.qq.com/a/20160304/059271.htm"
                      itemprop="url" class="buzz-item-link">
                        美公司员工花 25 美元就能买块苹果表，但有一个条件
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T08:33:59+0000">
                        2 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628667"
                        data-source-url="http://tech.qq.com/a/20160304/059271.htm" class="buzz-item-link">
                          tech.qq.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628480" data-source-url="http://tech.sina.com.cn/i/2016-03-04/doc-ifxqafha0365271.shtml"
                      itemprop="url" class="buzz-item-link">
                        美国商会起诉西雅图政府：担心损害 Uber 利益
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T06:04:07+0000">
                        5 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628480"
                        data-source-url="http://tech.sina.com.cn/i/2016-03-04/doc-ifxqafha0365271.shtml"
                        class="buzz-item-link">
                          tech.sina.com.cn
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628478" data-source-url="http://tech.163.com/16/0304/11/BHAGS04Q000915BD.html"
                      itemprop="url" class="buzz-item-link">
                        专家称 FBI 有能力从 iPhone 芯片中获取密码
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T06:01:33+0000">
                        5 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628478"
                        data-source-url="http://tech.163.com/16/0304/11/BHAGS04Q000915BD.html"
                        class="buzz-item-link">
                          tech.163.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628377" data-source-url="http://tech.sina.com.cn/i/2016-03-04/doc-ifxqafha0358568.shtml"
                      itemprop="url" class="buzz-item-link">
                        传腾讯将 10 亿美元入股搜狐视频 类似入股搜狗
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T03:09:43+0000">
                        8 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628377"
                        data-source-url="http://tech.sina.com.cn/i/2016-03-04/doc-ifxqafha0358568.shtml"
                        class="buzz-item-link">
                          tech.sina.com.cn
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628338" data-source-url="http://tech.ifeng.com/a/20160304/41558726_0.shtml"
                      itemprop="url" class="buzz-item-link">
                        阅后即焚 Snapchat 融资 1.75 亿美元 估值仍为 160 亿美元
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T02:46:42+0000">
                        8 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628338"
                        data-source-url="http://tech.ifeng.com/a/20160304/41558726_0.shtml" class="buzz-item-link">
                          tech.ifeng.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628257" data-source-url="http://cn.wsj.com/gb/20160303/tec074419.asp"
                      itemprop="url" class="buzz-item-link">
                        英特尔开发增强现实的头戴式设备
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T01:49:46+0000">
                        9 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628257"
                        data-source-url="http://cn.wsj.com/gb/20160303/tec074419.asp" class="buzz-item-link">
                          cn.wsj.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628245" data-source-url="http://cn.wsj.com/gb/20160303/tec112200.asp"
                      itemprop="url" class="buzz-item-link">
                        优步不惜重金扩张国际业务
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T01:21:01+0000">
                        10 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628245"
                        data-source-url="http://cn.wsj.com/gb/20160303/tec112200.asp" class="buzz-item-link">
                          cn.wsj.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628244" data-source-url="http://cn.wsj.com/gb/20160303/tec134755.asp"
                      itemprop="url" class="buzz-item-link">
                        谷歌电脑成“梵高再世”：画作拍出 8000 美元价格
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T01:20:18+0000">
                        10 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628244"
                        data-source-url="http://cn.wsj.com/gb/20160303/tec134755.asp" class="buzz-item-link">
                          cn.wsj.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="buzz-item">
                  <div class="buzz-item-container">
                    <h2 class="buzz-item-title" ga-track="event" ga-action="click" ga-event-category="widget"
                    ga-event-label="iycar-buzz">
                      <a target="_blank" href="http://www.iycar.com/buzz/628243" data-source-url="http://cn.wsj.com/gb/20160303/tec172731.asp"
                      itemprop="url" class="buzz-item-link">
                        百度李彦宏：加大力度发展自动驾驶技术
                      </a>
                    </h2>
                    <div class="buzz-item-footer">
                      <span class="buzz-item-date" itemprop="datePublished" datetime="2016-03-04T01:19:42+0000">
                        10 小时前
                      </span>
                      <span>
                        /
                      </span>
                      <span class="buzz-item-source">
                        Source:
                        <a target="_blank" itemprop="url" href="http://www.iycar.com/buzz/628243"
                        data-source-url="http://cn.wsj.com/gb/20160303/tec172731.asp" class="buzz-item-link">
                          cn.wsj.com
                        </a>
                      </span>
                    </div>
                  </div>
                </li>
                <!-- buzz item -->
                <li class="loading js-loading">
                  <img src="http://cdnzz.iycar.com/wp-content/themes/iycar-2.0/static/images/common/loader/loadingb.gif"
                  />
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div id="iycar_side_data_widget-4" class="widget-container widget-data clearfix">
          <div class="widget-data-content">
            <div class="widget-data-content-bg">
            </div>
            <h4>
              <a href="http://www.iycar.com/data/">
                数读
              </a>
            </h4>
            <a class="widget-body" rel="external" href="http://www.iycar.com/data/628594">
              <span class="widget-data-num num font-luzsans">
                5.7
              </span>
              <span class="widget-data-percent yahei">
                %
              </span>
              <span class="widget-data-text">
                IDC：今年智能手机出货量将仅增长 5.7%
              </span>
            </a>
            <a id="widget-data-more" class="widget-data-more" href="http://www.iycar.com/data/"
            title="点击了解更多">
              了解更多 &raquo;
            </a>
          </div>
        </div>
        <div id="recentcomments2" class="widget-container widget_recentcomments yth-post-list-widget  clearfix">
          <div class="title">
            <img class="iycar2015" src="http://cdnzz.iycar.com/wp-content/themes/iycar-2.0/static/images/desktop/latest-comments-icon.png"
            alt="" />
            <h2>
              最近评论
            </h2>
          </div>
          <ul>
            <li class="rc-navi clearfix">
              <span class="rc-loading">
                Loading...
              </span>
            </li>
            <li id="rc-comment-temp" class="rc-item rc-comment clearfix">
              <div class="rc-excerpt">
              </div>
              <div class="rc-info">
              </div>
              <div class="rc-timestamp">
              </div>
            </li>
          </ul>
        </div>
        <div id="mail-subscribe" class="widget-yth yth-subscribe widget-container clearfix">
          <div id="mc_embed_signup" class="clearfix">
            <form action="http://iycar.us2.list-manage.com/subscribe/post?u=f770959951cdcc1bba7ab56cb&amp;id=258559241a"
            method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form"
            class="validate" target="_blank">
              <div class="widget-header">
                <label for="mce-EMAIL">
                  爱范消息 | Exploring Leading Tech
                </label>
              </div>
              <div class="widget-contents clearfix">
                <p>
                  轻量、专注的消息，关注移动互联网、创投、智能设备的新鲜资讯。需各种邀请码，也请加入列表。
                </p>
                <div class="yth-input-group">
                  <input type="email" value="" name="EMAIL" class="yth-input email-input"
                  id="mce-EMAIL" placeholder="填写邮箱，订阅我们">
                  <input ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="Subscribe"
                  type="submit" value="订阅" name="subscribe" id="mc-embedded-subscribe" class="yth-input email-submit">
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="video-wrapper">
    <div class="video-container">
      <div class="video-feature-container js-video-container" data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ4NTg0MzY4OA==' frameborder=0 allowfullscreen></ythame>"
      ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
        <div class="mask video-mask">
        </div>
        <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/80013.jpg')">
        </div>
        <div class="video-play-button js-play-btn">
          <i class="iycar2015 iycar2015-shipin">
          </i>
        </div>
        <div class="feature-item-container">
          <div class="tag-label">
            <a class="tag" itemprop="keywords" href="http://www.iycar.com/video">
              爱范视频
            </a>
            <span class="seperator">
              |
            </span>
            <span class="time js-date">
              02月29日 17:44
            </span>
          </div>
          <h2 class="title">
            【爱范儿出品】一个游戏告诉你，小李子陪跑奥斯卡有多难
          </h2>
          <p class="description">
            今天的爱范儿大件事，我们就拿 Red Carpet Rampage 这款游戏来讲讲小李子的奥斯卡陪跑史。
          </p>
        </div>
      </div>
      <div class="video-list-container">
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/626463"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ4NTg0MzY4OA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/80013.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】一个游戏告诉你，小李子陪跑奥斯卡有多难
            </div>
            <div class="video-time">
              时长: 01:33
            </div>
            <div class="video-date">
              02-29
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/625335"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ4Mjg2MTQwMA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/爱范品.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范品】第75期：各种帮你更好剁手的 XX Pay
            </div>
            <div class="video-time">
              时长: 03:10
            </div>
            <div class="video-date">
              02-26
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/625030"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ4MjAzNTU4MA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/80012.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】三星智付 Samsung Pay 试用
            </div>
            <div class="video-time">
              时长: 02:27
            </div>
            <div class="video-date">
              02-26
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/624350"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ4MDc5MjA0NA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/80010.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】小米手机 5 上手试用视频
            </div>
            <div class="video-time">
              时长: 03:04
            </div>
            <div class="video-date">
              02-24
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/623130"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ3OTM1ODUyMA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/8009.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】诺基亚 5G 生态系统技术：Nokia AirScale
            </div>
            <div class="video-time">
              时长: 00:36
            </div>
            <div class="video-date">
              02-23
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/623113"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ3OTM2NTU2MA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/8008.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】编辑带你逛 MWC 2016，看看开幕第一天的新品
            </div>
            <div class="video-time">
              时长: 05:50
            </div>
            <div class="video-date">
              02-23
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/622967"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ3OTA2MjY4OA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/8007.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】MWC 手机汇总
            </div>
            <div class="video-time">
              时长: 03:51
            </div>
            <div class="video-date">
              02-22
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/621797"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ3NDY5NjEzMg==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url(' http://images.iycar.cn/wp-content/uploads/2016/02/8006.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】苹果 Apple Pay 第一时间抢鲜试用
            </div>
            <div class="video-time">
              时长: 02:28
            </div>
            <div class="video-date">
              02-19
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/621796"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ3NDI3MzIwOA==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/8005.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范品】第74期：除了上春晚，机器人还可以……
            </div>
            <div class="video-time">
              时长: 03:19
            </div>
            <div class="video-date">
              02-19
            </div>
          </div>
        </a>
        <a class="list-item-container js-list-video" href="http://www.iycar.com/video/620579"
        data-video-ythame="<ythame src='http://player.youku.com/embed/XMTQ3MzQ2MjQ1Ng==' frameborder=0 allowfullscreen></ythame>"
        ga-track="event" ga-action="click" ga-event-category="video" ga-event-label="爱范视频">
          <div class="mask video-mask-black">
          </div>
          <div class="mask video-play-mask">
            <i class="iycar2015 iycar2015-bofang">
            </i>
            <span class="play-text">
              播放中...
            </span>
          </div>
          <div class="bg-img" style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/02/8004.jpg')">
          </div>
          <div class="video-info-container">
            <div class="video-headline">
              【爱范儿出品】3 分半提前逛完 MWC
            </div>
            <div class="video-time">
              时长: 03:40
            </div>
            <div class="video-date">
              02-16
            </div>
          </div>
        </a>
      </div>
    </div>
    <div class="mask video-mask-left mask-bg-left">
    </div>
    <div class="mask video-list-mask mask-bg-right">
    </div>
  </div>
  <div id="index-part-two" data-cmpt-autofixed-container class="fullwidth row">
    <div class="main js-index-part-two">
      <div class="index-content-normal posts-list">
        <article itemscope itemtype="http://schema.org/Article" id="post-622387"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/app/622387"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/sifotography1412000831.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/app/622387" title="Permalink to 苹果重点推荐的剪贴板神器，到底有多好用？- Pin #iOS #AppStory">
                <span itemprop="headline">
                  苹果重点推荐的剪贴板神器，到底有多好用？- Pin #iOS #AppStory
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/app/622387#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  2
                </a>
                <meta itemprop="commentCount" content="2" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              原来，剪贴板还可以这么用！
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/app/">
                AppSolution
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/ricol009" title="Posts by 岛本初" rel="author">
                  岛本初
                </a>
              </span>
              <meta itemprop="author" content="岛本初" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T06:38:58+0800">
                4 小时前
              </span>
            </div>
          </div>
        </article>
        <article itemscope itemtype="http://schema.org/Article" id="post-628304"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628304"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/duibi.png!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628304" title="Permalink to 想要变高变年轻？上天可能是一个办法">
                <span itemprop="headline">
                  想要变高变年轻？上天可能是一个办法
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628304#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  2
                </a>
                <meta itemprop="commentCount" content="2" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              340 天的太空生活，这只是人类向移居太空迈出的一小步。
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/innovation">
                新创
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/zhangbowen" title="Posts by 张博文"
                rel="author">
                  张博文
                </a>
              </span>
              <meta itemprop="author" content="张博文" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T06:25:22+0800">
                5 小时前
              </span>
            </div>
          </div>
        </article>
      </div>
    </div>
    <div class="sbl row">
    </div>
    <div class="sbl row">
      <div data-cmpt-autofixed data-autofixed-follow-to=".js-index-part-two">
      </div>
    </div>
  </div>
  <div id="mindstore-container" class="mindstore-container">
    <div class="section-mindstore">
      <!--<i class="iycar2015 iycar2015-ms"></i>-->
      <span class="title">
        <img src="http://cdnzz.iycar.com/wp-content/themes/iycar-2.0/static/images/desktop/mindstore.png"
        />
      </span>
    </div>
    <div class="mindstore-articles-container">
      <div id="mindstore-wrapper" class="mindstore-wrapper banner js-mindstore"
      data-count="4">
        <div id="mindstore-articles-list" class="mindstore-articles-list row">
          <div class="no-ajax loading loading-gif js-loading">
            <img src="http://cdnzz.iycar.com/wp-content/themes/iycar-2.0/static/images/common/loader/loadingb.gif"
            />
          </div>
        </div>
      </div>
      <span class="unslider-arrow prev js-arrow">
        <i class="iycar2015 iycar2015-shangyihua">
        </i>
      </span>
      <span class="unslider-arrow next js-arrow">
        <i class="iycar2015 iycar2015-xiayihua">
        </i>
      </span>
      <div class="fullwidth">
        <a href="http://mindstore.io" class="guide">
          前往 MindStore.io &#8594;
        </a>
      </div>
    </div>
  </div>
  <div id="index-part-forth" data-cmpt-autofixed-container class="fullwidth row">
    <div class="main js-index-part-forth">
      <div class="index-content-normal posts-list js-loading-posts-wrapper">
        <article itemscope itemtype="http://schema.org/Article" id="post-628223"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628223"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/samsung-SSD.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628223" title="Permalink to 三星新出的固态硬盘，容量世界第一">
                <span itemprop="headline">
                  三星新出的固态硬盘，容量世界第一
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628223#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  9
                </a>
                <meta itemprop="commentCount" content="9" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              容量达到了 15.36TB。
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/product">
                产品
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/nemo603" title="Posts by 李 谋" rel="author">
                  李 谋
                </a>
              </span>
              <meta itemprop="author" content="李 谋" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T02:48:38+0800">
                8 小时前
              </span>
            </div>
          </div>
        </article>
        <article itemscope itemtype="http://schema.org/Article" id="post-628267"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628267"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/Great_Gatsby-05929Rr.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628267" title="Permalink to 硅谷的有钱人平时都怎么过？或许可以参考这本“硅谷装腔指南”">
                <span itemprop="headline">
                  硅谷的有钱人平时都怎么过？或许可以参考这本“硅谷装腔指南”
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628267#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  1
                </a>
                <meta itemprop="commentCount" content="1" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              在你的想象中，那些在硅谷的高科技产业骄子们平时是怎么生活的？
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/business">
                商业
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/huangmeijing" title="Posts by 黄 美菁"
                rel="author">
                  黄 美菁
                </a>
              </span>
              <meta itemprop="author" content="黄 美菁" />
              <span class="date" itemprop="datePublished" datetime="2016-03-04T02:42:02+0800">
                8 小时前
              </span>
            </div>
          </div>
        </article>
        <article itemscope itemtype="http://schema.org/Article" id="post-628018"
        class="row post-item-container">
          <div class="new-post-item-content">
            <a rel="canonical" class="news-pic" itemprop="thumbnailUrl" href="http://www.iycar.com/628018"
            style="background-image:url('http://images.iycar.cn/wp-content/uploads/2016/03/Mighty_hiking.0.jpg!400')">
            </a>
            <h2>
              <a rel="external" href="http://www.iycar.com/628018" title="Permalink to 手机怕摔，iPod 嫌麻烦？用它边听音乐边运动是一个好选择">
                <span itemprop="headline">
                  手机怕摔，iPod 嫌麻烦？用它边听音乐边运动是一个好选择
                </span>
              </a>
              <div class="comment-count new-comment-count">
                <a rel="canonical" class="comment-count-container" href="http://www.iycar.com/628018#comments"
                ga-track="event" ga-action="click" ga-event-category="button" ga-event-label="CommentCount">
                  <i class="iycar2015 iycar2015-pinglun">
                  </i>
                  15
                </a>
                <meta itemprop="commentCount" content="15" />
              </div>
            </h2>
            <p itemprop="description" class="js-excerpt" data-clamp="2">
              可以听流媒体的音乐播放器，带着它运动，从此再不怕手机被摔了。
            </p>
            <div class="tag-label">
              <a class="tag" itemprop="keywords" href="http://www.iycar.com/category/special/innovation">
                新创
              </a>
              <span class="seperator">
                |
              </span>
              <span class="author">
                <a href="http://www.iycar.com/author/nemo603" title="Posts by 李 谋" rel="author">
                  李 谋
                </a>
              </span>
              <meta itemprop="author" content="李 谋" />
              <span class="date" itemprop="datePublished" datetime="2016-03-03T12:09:13+0800">
                23 小时前
              </span>
            </div>
          </div>
        </article>
      </div>
    </div>
    <div class="sbl row">
      <div data-cmpt-autofixed data-autofixed-follow-to=".js-index-part-forth">
      </div>
    </div>
  </div>
  <div class="fullwidth row">
    <div class="main">
      <div class="loading-posts" id="loading-more-container">
        <a id="JS_loadMore" class="no-ajax load-more-link" data-home="1" data-page="2"
        href="javascript:void(0);">
          加载更多
        </a>
        <a id="no-articles" class="no-ajax no-articles hide" href="javascript:void(0);">
          没有更多了
        </a>
        <div id="JS_loading" class="no-ajax loading loading-gif">
          <img src="http://cdnzz.iycar.com/wp-content/themes/iycar-2.0/static/images/common/loader/loadingb.gif"
          />
        </div>
      </div>
    </div>
  </div>
</div>
<!--end content-->
</div>
<!--end content-outer -->
<!-- 底部 -->
<?php get_footer(); ?>